<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include "../../connection.php";

// Default to current month and year
$selectedMonth = isset($_GET['month']) ? $_GET['month'] : date('m');
$selectedYear = isset($_GET['year']) ? $_GET['year'] : date('Y');
$station_id = $_SESSION['stationId'];
// Start and end date for the selected month
$startDate = "$selectedYear-$selectedMonth-01";
$endDate = date("Y-m-t", strtotime($startDate));

$sql = "
    SELECT 
        bap.paramName AS task, 
        bp.db_pagename AS parameters, 
        bas.db_surveyValue AS Quality_of_done_work,
        bu.db_username AS name,
        bs.stationName AS station_name,
        bo.db_Orgname AS organisation_name,
        bd.DivisionName AS division_name,
        CASE 
            WHEN bas.db_surveyValue IN (9, 10) THEN 'Excellent'
            WHEN bas.db_surveyValue IN (7, 8) THEN 'Very Good'
            WHEN bas.db_surveyValue IN (5, 6) THEN 'Good'
            WHEN bas.db_surveyValue IN (3, 4) THEN 'Average'
            WHEN bas.db_surveyValue IN (1, 2) THEN 'Poor'
            ELSE 'Not Applicable'
        END AS payable_grade,
        bp.db_pageChoice AS grade,
        bp.db_pageChoice2 AS rank1,
        DATE(bas.created_date) AS report_date
    FROM 
        baris_param bap
        INNER JOIN baris_survey bas ON bap.paramId = bas.db_surveyParamId
        INNER JOIN baris_page bp ON bas.db_surveyPageId = bp.pageId
        INNER JOIN baris_userlogin bu ON bas.db_surveyUserid = bu.userId
        INNER JOIN baris_station bs ON bas.db_surveyStationId = bs.stationId
        INNER JOIN baris_organization bo ON bas.OrgID = bo.OrgID
        INNER JOIN baris_division bd ON bas.DivisionId = bd.DivisionId
    WHERE 
        bas.db_surveyStationId = '$station_id' 
        AND bas.created_date >= '$startDate' 
        AND bas.created_date <= '$endDate'
    ORDER BY report_date;
";

$result = $conn->query($sql);

$totalScore = 0;
$totalRecords = 0;
$maxScorePerDay = 300;
$inspections = [];
// Initialize an array to track unique dates
$uniqueDates = [];
// Get all dates in the selected month
$allDates = [];
$currentDate = strtotime($startDate);
$endDateTime = strtotime($endDate);

// Get all dates for the month
while ($currentDate <= $endDateTime) {
    $allDates[] = date('Y-m-d', $currentDate);
    $currentDate = strtotime('+1 day', $currentDate);
}

// Initialize variables for summary
$auditor = '';
$division = '';
$station = '';
$contractor = '';

// Loop through the result set
while ($row = $result->fetch_assoc()) {
    $reportDate = $row['report_date'];
    
    // Set summary values once (assuming all rows have the same values)
    if (empty($auditor)) {
        $auditor = $row['name'];
    }
    if (empty($division)) {
        $division = $row['division_name'];
    }
    if (empty($station)) {
        $station = $row['station_name'];
    }
    if (empty($contractor)) {
        $contractor = $row['organisation_name'];
    }
    
    // Track unique dates
    if (!in_array($reportDate, $uniqueDates)) {
        $uniqueDates[] = $reportDate;
    }

    // Sum up scores
    if (!isset($inspections[$reportDate])) {
        $inspections[$reportDate] = [
            'date' => $reportDate,
            'total' => $maxScorePerDay, 
            'score' => 0,
            'percentage' => 0
        ];
    }

    $inspections[$reportDate]['score'] += $row['Quality_of_done_work'];
    $inspections[$reportDate]['percentage'] = round(($inspections[$reportDate]['score'] / $maxScorePerDay) * 100, 2);
}

// Add missing dates with zero values
foreach ($allDates as $date) {
    if (!isset($inspections[$date])) {
        $inspections[$date] = [
            'date' => $date,
            'total' => $maxScorePerDay,
            'score' => 0,
            'percentage' => 0
        ];
    }
}

// Sort by date to ensure correct order
ksort($inspections);

// Calculate summary
$totalInspections = count($allDates);
$totalScore = array_sum(array_column($inspections, 'score'));
$maximumPossibleScore = $totalInspections * $maxScorePerDay;
$overallAverage = ($maximumPossibleScore > 0) ? round(($totalScore / $maximumPossibleScore) * 100, 2) : 0;




$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Summarry report <?php echo $station; ?> </title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-weight: 100;
            font-size: 12px;
            font-family: 'Roboto';
        }
        .container {
            width: 80%;
            margin: auto;
            page-break-after: always;
        }
        .report-title {
            text-align: center;
            font-weight: bold;

        }
        .report-subtitle {
            text-align: center;
            margin-bottom: 20px;
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
        }
        .section-title {
            text-align: center;
            font-weight: bold;
            padding: 5px;
            background-color: #e0e0e0;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid black;
            text-align: center;
            padding:0px;
        }
        th {
            background-color: #f2f2f2;
        }
        table th:nth-child(1) { width: 5%; }   
        table th:nth-child(2) { width: 30%; } 
        table th:nth-child(3) { width: 20%; }  
        table th:nth-child(4) { width: 10%; } 
        table th:nth-child(5) { width: 10%; }  
        table th:nth-child(6) { width: 10%; }

    </style>

</head>
<body class="bg-gray-100">
    <div class="max-w-6xl mx-auto bg-white rounded-2xl shadow-lg">
        <h2 class="text-center text-2xl font-bold mb-4">SOUTH CENTRAL RAILWAY</h2>
        <div class="max-w-6xl mx-auto bg-white p-6 rounded-2xl shadow-lg mb-6">
    <h2 class="text-center text-2xl font-bold mb-4">Daily Surprise Report Summary</h2>
    <p class="text-center text-gray-700 space-y-1">
        <span class="font-semibold">Month:</span> <span><?php echo date('F Y', strtotime("$selectedYear-$selectedMonth-01")); ?></span> &nbsp;|&nbsp;

        
        <span class="font-semibold">Division:</span> <span><?php echo $division; ?></span> &nbsp;|&nbsp;
        <span class="font-semibold">Station:</span> <span><?php echo $station; ?></span><br>
        <span class="font-semibold">Name Of Contractor:</span> <span><?php echo $contractor; ?></span> &nbsp;|&nbsp;
        <span class="font-semibold">Overall Average:</span> <span><?php echo $overallAverage; ?>%</span> &nbsp;|&nbsp;
        <span class="font-semibold">Total Score Obtained:</span> <span><?php echo $totalScore; ?></span>
    </p>
    <p  class="font-semibold text-center">Daily uses of type and quantity of consumables of environmental sanitation, mechanized cleaning and housekeeping contract at <?php echo $station; ?> Railway station</p>
</div>

        <form method="get" class="flex justify-center gap-4 mb-4">
            <select name="month" class="border p-2 rounded">
                <?php
                for ($i = 1; $i <= 12; $i++) {
                    $month = str_pad($i, 2, '0', STR_PAD_LEFT);
                    $selected = ($month == $selectedMonth) ? 'selected' : '';
                    echo "<option value='$month' $selected>" . date('F', strtotime("2023-$month-01")) . "</option>";
                }
                ?>
            </select>
            <input type="number" name="year" value="<?php echo $selectedYear; ?>" class="border p-2 rounded w-20" />
            <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-xl hover:bg-green-600">GO</button>
        </form>

        <table class="min-w-full bg-white border border-gray-300">
            <thead>
                <tr>
                    <th class="border px-4 py-2">S.No</th>
                    <th class="border px-4 py-2">Inspection Date</th>
                    <th class="border px-4 py-2">Total</th>
                    <th class="border px-4 py-2">Score</th>
                    <th class="border px-4 py-2">Score(%)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $serialNo = 1;
                foreach ($inspections as $inspection) {
                    echo "<tr>
                        <td class='border px-4 py-2 text-center'>{$serialNo}</td>
                        <td class='border px-4 py-2 text-center'>{$inspection['date']}</td>
                        <td class='border px-4 py-2 text-center'>{$inspection['total']}</td>
                        <td class='border px-4 py-2 text-center'>{$inspection['score']}</td>
                        <td class='border px-4 py-2 text-center'>{$inspection['percentage']}</td>
                    </tr>";
                    $serialNo++;
                }
                ?>
            </tbody>
        </table>
    </div>

    <div class="max-w-6xl mx-auto bg-white p-6 mt-6 rounded-2xl shadow-lg">
        <h2 class="text-center text-2xl font-bold mb-4">Summary Report</h2>
        <table class="min-w-full bg-white border border-gray-300">
            <thead>
                <tr>
                    <th class="border px-4 py-2">Total Inspections</th>
                    <th class="border px-4 py-2">Total Score</th>
                    <th class="border px-4 py-2">Maximum Possible Score</th>
                    <th class="border px-4 py-2">Average Score (%)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="border px-4 py-2 text-center"><?php echo $totalInspections; ?></td>
                    <td class="border px-4 py-2 text-center"><?php echo $totalScore; ?></td>
                    <td class="border px-4 py-2 text-center"><?php echo $maximumPossibleScore; ?></td>
                    <td class="border px-4 py-2 text-center"><?php echo $overallAverage; ?>%</td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
