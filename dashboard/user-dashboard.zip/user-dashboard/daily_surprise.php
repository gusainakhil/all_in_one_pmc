<?php session_start(); 
 include"../../connection.php";?>
<!doctype html>
<html lang="en">
  <?php
    
  include"head.php"

  ?>
 
  <!--begin::Body-->
  <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        
     <?php include"header.php"?>
      <main class="app-main">
        <div class="app-content-header">
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Daily surpise Report </h3></div>
            </div>
          </div>
        </div>
        <div class="app-content">
          <div class="container-fluid">
            <div class="row g-4">
              <div class="col-md-12">
                <div class="card card-outline mb-4">
                  <form class="needs-validation" novalidate>
                    <!--begin::Body-->
                    <div class="card-body">
                      <!--begin::Row-->
                      <div class="row g-3">
                        <div class="col-md-6">
                            <br>
                             <a href="Daily-surprise-visit.php"  class="btn-gradient btn btn-success" target="blank" >
                          <i class="fa fa-bell‑ring"></i> Daily Surprise Report
                        </a>
       
                 <a href="daily_surprise_summary.php"  class="btn-gradient btn btn-success" target="blank"  >
                          <i class="fa fa-bell‑ring"></i> Daily Surprise Summary
                        </a>
                        </div>
 
                      </div>
                      <!--end::Row-->
                    </div>
                  </form>
                </div>
              </div>
              <!--end::Col-->
            </div>
          </div>
        </div>
      </main>
      <!--end::App Main-->
      <!--begin::Footer-->
      <footer class="app-footer">
        <!--begin::To the end-->
        <div class="float-end d-none d-sm-inline">Anything you want</div>
        <strong>
          Copyright &copy; 2025&nbsp;
          <a href="#" class="text-decoration-none"></a>.
        </strong>
        All rights reserved.
        <!--end::Copyright-->
      </footer>
      <!--end::Footer-->
    </div>
    <script
      src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.10.1/browser/overlayscrollbars.browser.es6.min.js"
      integrity="sha256-dghWARbRe2eLlIJ56wNB+b760ywulqK3DzZYEpsg2fQ="
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
      integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
      crossorigin="anonymous"
    ></script>
   
   
    
  </body>
</html>
