<?php 
    // Start the session
    // Check if userId is not set
    if (!isset($_SESSION['userId']) || empty($_SESSION['userId'])) {
        // Destroy the session
        session_unset();
        session_destroy();
        header("Location: https://pmc.beatleme.co.in/");
        exit();
    }
?>
<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
    include"../../connection.php";
?>
<?php 
 $user_id = $_SESSION['userId'];
    $_SESSION['stationId'];
   $_SESSION['db_usertype'];
 $_SESSION['OrgID'];


$sql = "SELECT 
            baris_userlogin.userId, 
            baris_userlogin.OrgID, 
            baris_userlogin.StationId, 
            baris_station.db_questionsId, 
            baris_question.queId, 
            baris_question.queName, 
            baris_question.subqueId, 
            baris_subquestion.subqueName,
            baris_subquestion.subqueType,
            baris_subquestion.subqueId AS report_id
        FROM 
            baris_userlogin 
        JOIN 
            baris_station ON baris_userlogin.OrgID = baris_station.OrgID 
        JOIN 
            baris_question ON baris_station.db_questionsId = baris_question.queId 
        JOIN 
            baris_subquestion ON FIND_IN_SET(baris_subquestion.subqueId, baris_question.subqueId)
        WHERE 
            baris_userlogin.userId = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);  
$stmt->execute();
$result = $stmt->get_result();
?>
  <style>
    body { 
    font-family: "Times New Roman", Times, serif;
       
    }
  
    </style>
<nav class="app-header navbar navbar-expand bg-body" style="background: #3c8dbc !important;">
        <!--begin::Container-->
        <div class="container-fluid">
          <!--begin::Start Navbar Links-->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" data-lte-toggle="sidebar" href="#"
                role="button">
                <i class="bi bi-list"></i>
              </a>
            </li>
            <li style="float: left;font-size: 25px;color: #fff;font-weight:100; margin-left: 11px;line-height: 50px;" class="nav-item d-none d-md-block">INDIAN RAILWAYS -  Platform Mechanized Cleanliness</li>
           
          </ul>
          <!--end::Start Navbar Links-->
          <!--begin::End Navbar Links-->
          <ul class="navbar-nav ms-auto">
            <!--begin::Navbar Search-->

            
            <li class="nav-item dropdown user-menu">
              <a href="" class="nav-link dropdown-toggle"
                data-bs-toggle="dropdown">
       
                <span class="brand-text fw-light" style="color:white" >sign Out</span>
              </a>
              <!--<ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">-->
                <!--begin::User Image-->
                <!--<li class="user-header text-bg-primary">-->
                <!--  <img-->
                <!--    src="../assets/img/user2-160x160.jpg"-->
                <!--    class="rounded-circle shadow"-->
                <!--    alt="User Image" />-->
                <!--  <p>-->
                <!--   Beatle Analytics-->
                <!--  </p>-->
                <!--</li>-->

                <!--end::Menu Footer-->
              <!--</ul>-->
            </li>
            <!--end::User Menu Dropdown-->
          </ul>
          <!--end::End Navbar Links-->
        </div>
        <!--end::Container-->
      </nav>
      <!--end::Header-->
      <!--begin::Sidebar-->
      <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
        <!--begin::Sidebar Brand-->
        <div class="sidebar-brand">
          <!--begin::Brand Link-->
          <a href="./index.php" class="brand-link">
            <!--begin::Brand Image-->
            <img
              src="../assets/img/tarin_logo.png"
              alt="AdminLTE Logo"
              class="brand-image opacity-75 shadow" />
            <!--end::Brand Image-->
            <!--begin::Brand Text-->
            <span class="brand-text fw-light">India RAILWAY</span>
            <!--end::Brand Text-->
          </a>
          <!--end::Brand Link-->
        </div>
        <!--end::Sidebar Brand-->
        <!--begin::Sidebar Wrapper-->
        <div class="sidebar-wrapper">
          <nav class="mt-2">
            <!--begin::Sidebar Menu-->
            <ul
              class="nav sidebar-menu flex-column"
              data-lte-toggle="treeview"
              role="menu"
              data-accordion="false">
              <li class="nav-item menu-open">
                <a href="#" class="nav-link active">
                  <i class="nav-icon bi bi-speedometer"></i>
                  <p>
                    Dashboard
                    <i class="nav-arrow bi bi-chevron-right"></i>
                  </p>
                </a>

              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon bi bi-box-seam-fill"></i>
                  <p>
                    Pmc
                    <i class="nav-arrow bi bi-chevron-right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                    
                    
                    <?php 
                  while($row = $result->fetch_assoc()) {
                        echo '<li class="nav-item">
                                   <a href="' . htmlspecialchars($row["subqueType"]) . '.php?id=' .($row["report_id"]). '" class="nav-link">
                                    <i class="nav-icon bi bi-circle"></i>
                                    <p>' . htmlspecialchars($row["subqueName"]) . '</p>
                                </a>
                              </li>';
                    }
                

                   ?>        
                  
                  
                  <li class="nav-item">
                    <a href="billing-invoice.php" class="nav-link">
                      <i class="nav-icon bi bi-circle"></i>
                      <p>billig Invoice  </p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="nav-icon bi bi-circle"></i>
                  <p>Passenger Feedback </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="equipments.php" class="nav-link">
                  <i class="nav-icon bi bi-circle"></i>
                  <p>equipments</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="photo-report.php" class="nav-link">
                  <i class="nav-icon bi bi-circle"></i>
                  <p>Photo Report </p>
                </a>
              </li>
            </ul>
            <!--end::Sidebar Menu-->
          </nav>
        </div>
        <!--end::Sidebar Wrapper-->
      </aside>