<!doctype html>
<html lang="en">
  <!--begin::Head-->
     <?php include"head.php" ?>
  <style>
    body { padding: 20px; }
    .invoice-box { border: 1px solid #ddd; padding: 20px; background: #fff; }
    .table th, .table td { text-align: center; }
</style>
  <!--end::Head-->
  <!--begin::Body-->
  <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
       <?php include"header.php" ?>
      <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Billig Report </h3></div>
              
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row g-4">
              <div class="col-md-12">
                <div class="card card-info card-outline mb-4">
                  <form class="needs-validation" novalidate>
                    <!--begin::Body-->
                    <div class="card-body">
                      <!--begin::Row-->
                      <div class="row g-3">
                       
                        <div class="col-md-2">
                          <label for="validationCustom04" class="form-label">Select station</label>
                          <select class="form-select" id="validationCustom04" required>
                            <option selected disabled value="">Choose...</option>
                            <option>...</option>
                          </select>
                         
                        </div>
                        <div class="col-md-2">
                          <label for="validationCustom04" class="form-label">surpise Report</label>
                          <select class="form-select" required>
                            <option selected disabled value="">Choose...</option>
                            <option>...</option>
                          </select>
                          
                        </div>
                        <div class="col-md-2">
                          <label for="validationCustom04" class="form-label">Select Auditior</label>
                          <select class="form-select"  required>
                            <option selected disabled value="">Choose...</option>
                            <option>...</option>
                          </select>
                         
                        </div>
                        <div class="col-md-2">
                          <label for="validationCustom04" class="form-label">Select station</label>
                          <select class="form-select" required>
                            <option selected disabled value="">Choose...</option>
                            <option>...</option>
                          </select>
                          
                        </div>
                        <div class="col-md-2">
                          <label for="validationCustom04" class="form-label">From</label>
                          <input class="form-select"  type="date" name="submit ">
                          
                        </div>

                        <div class="col-md-2">
                          <label for="validationCustom04" class="form-label">From</label>
                          <input class="form-select"  type="date" name="submit ">
                        </div>

                        <div class="card-footer">
                          <button class="btn btn-info" type="submit">Submit form</button>
                          <a class="btn btn-success" href="impose-penalty.html" >impose-penalty</a>
                        </div>

                        
                        <!--end::Col-->
                      </div>
                      <!--end::Row-->
                    </div>
                    <!--end::Body-->
                    <!--begin::Footer-->
                   
                    <!--end::Footer-->
                  </form>
                  <!--end::Form-->
                  <!--begin::JavaScript-->
                  <script>
                    // Example starter JavaScript for disabling form submissions if there are invalid fields
                    (() => {
                      'use strict';

                      // Fetch all the forms we want to apply custom Bootstrap validation styles to
                      const forms = document.querySelectorAll('.needs-validation');

                      // Loop over them and prevent submission
                      Array.from(forms).forEach((form) => {
                        form.addEventListener(
                          'submit',
                          (event) => {
                            if (!form.checkValidity()) {
                              event.preventDefault();
                              event.stopPropagation();
                            }

                            form.classList.add('was-validated');
                          },
                          false,
                        );
                      });
                    })();
                  </script>
                  <!--end::JavaScript-->
                </div>
                <!--end::Form Validation-->
              </div>
              <!--end::Col-->
            </div>
            <div class="container invoice-box">
              <h4 class="text-center">PMC BILL INVOICE</h4>
              <h5 class="text-center">PAYABLE AMOUNT DESCRIPTION OF SANITATION WORK AT TIRUPATI STATION</h5>
              <table class="table table-bordered mt-3">
                  <tbody>
                      <tr>
                          <td><strong>SANCTIONED AMOUNT:</strong> 69570146.37</td>
                          <td><strong>DATE RANGE:</strong> 01.02.2025 to 28.02.2025</td>
                      </tr>
                      <tr>
                          <td><strong>NO OF WORKERS:</strong> 11+5+84</td>
                          <td><strong>PERFORMANCE GUARANTY:</strong> 9388253</td>
                      </tr>
                      <tr>
                          <td><strong>COST OF WORK PER MONTH:</strong> 1333308.76</td>
                          <td><strong>NUMBER OF DAYS FOR BILLING:</strong> 28</td>
                      </tr>
                  </tbody>
              </table>
      
              <h5 class="mt-4">Earnings</h5>
              <table class="table table-bordered">
                  <thead class="table-light">
                      <tr>
                          <th>S.NO</th>
                          <th>EARNINGS</th>
                          <th>WEIGHTAGE</th>
                          <th>SCORED</th>
                          <th>AMOUNT</th>
                      </tr>
                  </thead>
                  <tbody>
                      <tr><td>1</td><td>ATTENDANCE RECORDS OF THE STAFF</td><td>25%</td><td>0%</td><td>333327.19</td></tr>
                      <tr><td>2</td><td>CLEANLINESS RECORD</td><td>15%</td><td>97.44%</td><td>199996.31</td></tr>
                      <tr><td>3</td><td>USE OF TYPE AND QUANTITY OF CONSUMABLES</td><td>10%</td><td>55.04%</td><td>133330.88</td></tr>
                      <tr><td>4</td><td>MACHINERY USAGE</td><td>5%</td><td>100%</td><td>66665.44</td></tr>
                      <tr><td>5</td><td>SURPRISE VISITS CONDUCTED</td><td>10%</td><td>81.31%</td><td>133330.88</td></tr>
                      <tr><td>6</td><td>MACHINE CONSUMABLES</td><td>5%</td><td>46.43%</td><td>66665.44</td></tr>
                      <tr><td>7</td><td>PASSENGER FEEDBACK AND COMPLAINTS</td><td>30%</td><td>82.8%</td><td>399992.63</td></tr>
                      <tr><td colspan="4"><strong>TOTAL</strong></td><td><strong>1333308.77</strong></td></tr>
                  </tbody>
              </table>
      
              <h5 class="mt-4">Deductions</h5>
              <table class="table table-bordered">
                  <thead class="table-light">
                      <tr>
                          <th>S.NO</th>
                          <th>DEDUCTIONS</th>
                          <th>AMOUNT</th>
                      </tr>
                  </thead>
                  <tbody>
                      <tr><td>5</td><td>MANPOWER AND UNIFORM PENALTY</td><td>-942608</td></tr>
                      <tr><td>9</td><td>PENALTY IMPOSED DUE TO SHORTAGE OF MACHINE CONSUMABLES</td><td>48000</td></tr>
                      <tr><td>10</td><td>PENALTY DUE TO NON AVAILABILITY OF CHEMICALS</td><td>1144350</td></tr>
                      <tr><td colspan="2"><strong>TOTAL</strong></td><td><strong>249742</strong></td></tr>
                  </tbody>
              </table>
      
              <h5 class="mt-4 text-end">TOTAL PAYABLE AMOUNT: <strong>1083566.77</strong></h5>
              <h5 class="text-end">TOTAL ROUND OFF PAYABLE AMOUNT: <strong>1083567</strong></h5>
              <p class="text-center mt-4">IN WORDS: TEN LAKHS EIGHTY THREE THOUSANDS FIVE HUNDRED AND SIXTY SEVEN RUPEES</p>
              <p class="text-center">THIS IS A COMPUTER GENERATED INVOICE AND NO SIGNATURE IS REQUIRED.</p>
          </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>
      <!--end::App Main-->
      <!--begin::Footer-->
      <?php include "footer.php" ?>
      <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->
    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script
      src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.10.1/browser/overlayscrollbars.browser.es6.min.js"
      integrity="sha256-dghWARbRe2eLlIJ56wNB+b760ywulqK3DzZYEpsg2fQ="
      crossorigin="anonymous"
    ></script>
    <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"
    ></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
      integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
      crossorigin="anonymous"
    ></script>
    <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
    <script src="../../../dist/js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)--><!--begin::OverlayScrollbars Configure-->
    <script>
      const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
      const Default = {
        scrollbarTheme: 'os-theme-light',
        scrollbarAutoHide: 'leave',
        scrollbarClickScroll: true,
      };
      document.addEventListener('DOMContentLoaded', function () {
        const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
        if (sidebarWrapper && typeof OverlayScrollbarsGlobal?.OverlayScrollbars !== 'undefined') {
          OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
            scrollbars: {
              theme: Default.scrollbarTheme,
              autoHide: Default.scrollbarAutoHide,
              clickScroll: Default.scrollbarClickScroll,
            },
          });
        }
      });
    </script>
    <!--end::OverlayScrollbars Configure-->
    <!--end::Script-->
  </body>
  <!--end::Body-->
</html>
